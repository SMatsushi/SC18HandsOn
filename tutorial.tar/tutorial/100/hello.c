/* $ ncc hello.c
   $ ve_exec ./a.out
 */
#include <stdio.h>

int main() {
  printf("hello world\n");
}
